document.getElementById("userForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let valid = true;
  let successMsg = document.querySelector(".success-message");
  successMsg.textContent = "";
  document.querySelectorAll(".error").forEach(err => err.textContent = "");
  let name = document.getElementById("name");
  let email = document.getElementById("email");
  let phone = document.getElementById("phone");
  let password = document.getElementById("password");
  if (name.value.trim() === "") { name.nextElementSibling.textContent = "Name is required."; valid = false; }
  let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!emailPattern.test(email.value.trim())) { email.nextElementSibling.textContent = "Enter a valid email."; valid = false; }
  let phonePattern = /^[0-9]{10}$/;
  if (!phonePattern.test(phone.value.trim())) { phone.nextElementSibling.textContent = "Enter a valid 10-digit phone number."; valid = false; }
  if (password.value.length < 6) { password.nextElementSibling.textContent = "Password must be at least 6 characters."; valid = false; }
  if (valid) {
    successMsg.textContent = "🎉 Form submitted successfully!";
    document.getElementById("userForm").reset();
    successMsg.style.animation = "fadeIn 1s ease";
  }
});
